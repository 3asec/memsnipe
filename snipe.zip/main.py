from web3 import Web3
import json, time, requests, os, sys
from dotenv import load_dotenv
load_dotenv()
web3 = Web3(Web3.HTTPProvider(os.getenv('RPC_URL')))
w3 = Web3(Web3.HTTPProvider("https://mainnet-sequencer.base.org"))

with open('./abi.json') as f:
    abi = json.load(f)

with open("abi_router.json", "r") as f:
    abi_router = json.load(f)

os.system('cls' if os.name == 'nt' else 'clear')
if(web3.is_connected()):
    print(f"Starting Sniper\nEnhanced Version")
else:
    print("Failed to Connect to Base")
    sys.exit()

privatekey = os.getenv("PRIVATE_KEY")

address = web3.eth.account.from_key(privatekey).address
amounts = float(input("Enter Amount ETH to Snipe: "))
amount = web3.to_wei(amounts, 'ether')
minfollowers = int(input("Enter Minimum Followers: "))
print(f"Mempool Started From Block: {web3.eth.get_block('latest')['number']}")

contract_router = web3.eth.contract(
    address="0xBb5aFfB8d30004dd6E80EaD978EC28504a451F3A", 
    abi=abi_router)

contracts = web3.eth.contract(
    address='0x250c9FB2b411B48273f69879007803790A6AeA47',
    abi=abi
)

def swap_tx(token_address):
    tx = contract_router.functions.mempoolswap(web3.to_checksum_address(token_address)).build_transaction(
        {
            "from": web3.to_checksum_address(address),
            "value": amount,
            "gasPrice": int(web3.eth.gas_price*10),
            "gas": 0,
            "nonce": web3.eth.get_transaction_count(address)
        }
    )
    tx.update({'gas': int(web3.eth.estimate_gas(tx)*1.2)})
    signed_txns = web3.eth.account.sign_transaction(tx, private_key=privatekey)
    tx_hash = web3.eth.send_raw_transaction(signed_txns.raw_transaction)
    print("Recipt Swap >> " + web3.to_hex(tx_hash))

def check_deployer(deployer, token_address, name, symbol, supply):
    try:
        time.sleep(5)
        response = requests.get(f"https://relayer.host/api/{token_address}/{deployer}").json()
        Username = response["username"]
        followers = response["followers"]
        following = response["following"]
        data = (f'New Contract Detected\n>>> Contract Address: {token_address}\n>>> Name: {name}\n>>> Symbol: {symbol}\n>>> Deployer: {deployer}\n>>> Supply: {float(web3.from_wei(supply, 'ether'))}\n>>> Username: {Username}\n>>> Followers: {str(followers)}\n>>> Following: {str(following)}\n>>> Date: {time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())} UTC')
        print(data)
        if(int(followers) >= minfollowers):
            try:
                swap_tx(token_address)
            except Exception:
                swap_tx(token_address)
        else:
            print("Not Enough Followers Skipping...")
    except Exception:
        check_deployer(deployer, token_address, name, symbol, supply)

def handle_event(event):
    try:
        token_address = event['args']['tokenAddress']
        deployer = event['args']['deployer']
        name = event['args']['name']
        symbol = event['args']['symbol']
        supply = event['args']['supply']
        check_deployer(deployer, token_address, name, symbol, supply)
    except Exception as error:
        print("Error:", error)

event_filter = contracts.events.TokenCreated.create_filter(from_block='latest')
while True:
    try:
        for event in event_filter.get_new_entries():
            handle_event(event)
    except Exception as e:
        print("Error fetching new entries:", e)
    time.sleep(1)